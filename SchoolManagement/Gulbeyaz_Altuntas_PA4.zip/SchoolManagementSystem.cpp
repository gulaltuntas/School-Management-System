#include "SchoolManagementSystem.h"

namespace PA4 {

    SchoolManagementSystem::SchoolManagementSystem(){ // default

        studentReference = nullptr;
        courseReference = nullptr;
        student_size = 0;
        course_size = 0;

    }

    SchoolManagementSystem::SchoolManagementSystem(const SchoolManagementSystem &obj){ // copy

        student_size = obj.student_size;
        course_size = obj.course_size;

        if(student_size == 0){ // if student size is zero we set array to nullptr
            studentReference = nullptr; 
        }
        else{   
            studentReference = new Student[student_size]; // allocate memory
            for (int i = 0; i < student_size; i++){
                studentReference[i] = obj.studentReference[i]; // add it one by one
            }
        }

        if (course_size == 0){
            courseReference = nullptr;
        }
        else{
            courseReference = new Course[course_size];
            for (int i = 0; i < course_size; i++){
                courseReference[i] = obj.courseReference[i];
            }
        }

    }
    void SchoolManagementSystem::menu(){ // main menu 

        int choice;
        while(true){ // true loop
        cout << "MENU" << endl;
        cout << "0. Exit" << endl;
        cout << "1. Students" << endl;
        cout << "2. Course" << endl;
        cout << "3. List All Students" << endl;
        cout << "4. List All Courses" << endl;  

        cin >> choice;
            switch (choice){

                case 0:
                exit(5);
                break;

                case 1:
                student_menu(); // calling student menu function
                break;

                case 2:
                course_menu();  // calling course menu function
                break;

                case 3:
                list_all_students(); 
                break;

                case 4:
                list_all_courses();  
                break;
            }
        }

    }   

    void SchoolManagementSystem::student_menu(){

        int choice;
    
        while(choice != 0){

        cout << "0. up" << endl;
        cout << "1. add_student" << endl;
        cout << "2. select_student" << endl;

            cin >> choice;
            switch(choice){
                case 0: {
                    
                }
                break;

                case 1: {
                    int id;
                    string name = "";
                    string line;
                    string number = "";
                    cout << ">> ";
                    cin.ignore(2,'\n');  
                    getline(cin, line); // to add a student we get it as a string and then change the id to number
                    for(char c : line) {
                        if(c > 47 && c < 58) {
                            number += c;
                        }else {
                            name += c;
                        }
                    }
                    id = stoi(number);
                    Student *temp = new Student[student_size+1]; // allocating
                    for(int i = 0; i < student_size; i++) {
                        temp[i] = studentReference[i];
                    }

                    temp[student_size] = Student(name, id);
                
                    if(student_size != 0) {
                        delete[] studentReference; 
                    }

                    student_size++; 
                    studentReference = temp; 
                }
                break;
                
                case 2: {
                    select_student();
                }
                break;
            }
        }
    }


    void SchoolManagementSystem::course_menu(){

        int choice;
        
        while(choice != 0){

        cout << "0. up" << endl;
        cout << "1. add_course" << endl;
        cout << "2. select_course" << endl;


            cin >> choice;
            switch(choice){
                case 0: {

                }
                break;

                case 1: { // to take the name and code for the course 
                    string name = "";
                    string code = "";
                    cout << ">> ";
                    cin.ignore(2,'\n');
                    getline(cin, code, ' ');
                    getline(cin, name);
                    Course *temp = new Course[course_size+1];
                    for(int i = 0; i < course_size; i++) {
                        temp[i] = courseReference[i];
                    }

                    temp[course_size] = Course(name, code);
                
                    if(course_size != 0) {
                        delete[] courseReference; 
                    }

                    course_size++; 
                    courseReference = temp; 
                }
                break;
                
                case 2:
                    select_course(); // created another function for select_course operation
                break;

            }
        }
    }

    void SchoolManagementSystem::select_student(){
        
        int id;
        string name = "";
        string line;
        string number = "";
        cout << ">> ";
        cin.ignore(2,'\n');
        getline(cin, line);
        for(char c : line) {
            if(c > 47 && c < 58) {
                number += c;
            }else {
                name += c;
            }
        }
        id = stoi(number);
        int choice;
        int control = 0;
        for (int i = 0; i < student_size; i++){
            if (studentReference[i].student_id == id && studentReference[i].student_name == name){ // we check if we have the student and if we do then we will keep the index of it
                int index;
                for (int i = 0; i < student_size; i++){
                    if (studentReference[i].student_id == id){
                        index = i; // holds where the student is 
                    }
                }
                control = 1;
                while(choice != 0){
                    cout << "0. up" << endl;
                    cout << "1. delete_student" << endl;
                    cout << "2. add_selected_student_to_a_course" << endl;
                    cout << "3. drop_selected_student_from_a_course" << endl;
                    cin >> choice;
                    switch(choice) {
                        case 0: {

                        }
                        break;

                        case 1: {
                            
                            Student *temp = new Student [student_size - 1]; // initalize a temp and set size one less
                            for (int i = 0; i < index; i++){
                                temp[i] = studentReference[i]; // copy the dynamic array till index
                            }

                            for (int i = index + 1; i < student_size; i++){
                                temp[i - 1] = studentReference[i];
                            }
                            delete [] studentReference; // free memory
                            studentReference = temp;
                            student_size--; // decrease size 
                            choice = 0;
                            for(int i = 0; i < course_size; i++){
                                for (int j = 0; j < courseReference[i].size; j++){
                                    if (courseReference[i].studentReference[j].student_name == name && courseReference[i].studentReference[j].student_id == id){
                                        courseReference[i].deleteStudent(Student(name, id)); // and delete student if they are the same
                                    }
                                }
                            }
                        }
                        break;

                        case 2: { // add selected student to course
                            int *courseIndexes = new int[course_size]; // holds the numbers of the courses student is not enrolled
                            int a = 1;
                            cout << "0 UP" << endl;
                            for(int i = 0;i < course_size; i++) {
                                int equal = 0;
                                for(int j = 0; j < studentReference[index].size;j++) { // check all the courses
                                    if(courseReference[i].course_code == this->studentReference[index].courseReference[j].course_code) {
                                        equal = 1; // if the student does have one we end up as equal = 1 so break;
                                        break;
                                    }
                                }
                                if(equal != 1) { // that means the student doesnt have the code so we print it as the courses student doesnt take
                                        cout << a << " " << courseReference[i].course_code << " " << courseReference[i].course_name << endl;
                                        courseIndexes[a-1] = i;
                                        a++;
                                }
                            }
                            int which_course;
                            cout << ">> ";
                            cin >> which_course;
                            if(which_course > 0 && which_course < a) {
                                int courseIndex = courseIndexes[which_course-1];
                                delete[] courseIndexes; // free memory and add the course to the student
                                studentReference[index].addCourse(Course(courseReference[courseIndex].course_name,courseReference[courseIndex].course_code));
                                courseReference[courseIndex].addStudent(Student(name,id));
                            }else if(which_course == 0) {choice = 0;} 
                        }
                        break;
                        case 3: {
                            int i;
                            cout << "0 up" << endl;
                            for(i = 0;i < studentReference[index].size;i++) { 
                                cout << i+1 << " " << this->studentReference[index].courseReference[i].course_code << " " << this->studentReference[index].courseReference[i].course_name << endl;
                            }
                            int which_course;
                            cout << ">> ";
                            cin >> which_course; // ask which course the user wants to delete by entering the number of it 
                            if(which_course > 0 && which_course <= i) {
                                for(int i = 0;i < course_size;i++) {
                                    if(studentReference[index].courseReference[which_course-1].course_code == courseReference[i].course_code) { // delete the student from the specific course
                                        this->courseReference[i].deleteStudent(Student(studentReference[index].student_name,studentReference[index].student_id));
                                        break;
                                    }
                                }
                                studentReference[index].deleteCourse(Course(studentReference[index].courseReference[which_course-1].course_name,studentReference[index].courseReference[which_course-1].course_code));
                            }
                        }
                        break;
                    }
                }
                break;
            }
        }
        if(control != 1) {
            cout << "There is not a student like that." << endl;
        }
    }

    void SchoolManagementSystem::select_course(){
        string name;
        string code;
        cout << ">> "; // select the course name
        cin.ignore(2,'\n');
        getline(cin, code, ' ');
        getline(cin, name);
        int choice;
        int control = 0;
        for(int i = 0;i < course_size;i++) {
            if(courseReference[i].course_code == code && courseReference[i].course_name == name) {
                while(choice != 0){

                cout << "0. up" << endl;
                cout << "1. delete_course" << endl;
                cout << "2. list_students_registered_to_the_selected_course" << endl;

                    cin >> choice;
                    switch(choice) {
                        case 0: {

                        }
                        break;

                        case 1: {
                            int index;
                            for (int i = 0; i < course_size; i++){
                                if (courseReference[i].course_code == code){
                                    index = i; // hold the index of it 
                                }
                            }
                            Course *temp = new Course [course_size - 1]; // innitialize and allocate temp course
                            for (int i = 0; i < index; i++){
                                temp[i] = courseReference[i];
                            }
                            for (int i = index + 1; i < course_size; i++){
                                temp[i - 1] = courseReference[i];
                            }
                            delete [] courseReference;
                            courseReference = temp;
                            course_size--; // one less size
                            choice = 0;
                            for(int i = 0; i < student_size; i++){
                                for (int j = 0; j < studentReference[i].size; j++){ // if they are equal to each other then delete it by calling the deleteCourse
                                    if (studentReference[i].courseReference[j].course_name == name && studentReference[i].courseReference[j].course_code == code){
                                        studentReference[i].deleteCourse(Course(name, code));
                                    }
                                }
                            }
                        }
                                
                        break;

                        case 2: {
                            int index;
                            for (int i = 0; i < course_size; i++){
                                if (courseReference[i].course_code == code){
                                    index = i;
                                }
                            }                // list the students in that specific course
                            for (int i = 0; i < courseReference[index].size; i++){
                                cout << courseReference[index].studentReference[i].student_name << " " << courseReference[index].studentReference[i].student_id << endl;
                            }
                        }
                        break;
                    }
                }
                break;
            }
        }
    }



    void SchoolManagementSystem::list_all_students(){ // to list all the students
        for (int i = 0; i < student_size; i++){
            cout << i+1 << "- " << studentReference[i].student_name << " " << studentReference[i].student_id << endl;
        }
    }


    void SchoolManagementSystem::list_all_courses(){ // list all courses
        for (int i = 0; i < course_size; i++){
            cout << i+1 << "- " << courseReference[i].course_code << " " << courseReference[i].course_name << endl;
        }
    }

    SchoolManagementSystem::~SchoolManagementSystem(){ // to free the memory

        if (studentReference != nullptr){
            delete [] studentReference;
        }
        if (courseReference != nullptr){
            delete [] courseReference;
        } 
    }
}