#ifndef SCHOOLMANAGEMENTSYSTEM_H
#define SCHOOLMANAGEMENTSYSTEM_H
#include <string>
#include <iostream>
#include "student.h"
#include "course.h"


using namespace std;

namespace PA4 {
    class SchoolManagementSystem{

        private:
        Student *studentReference; // dynamic array that holds students
        Course *courseReference; // dynamic array that holds courses
        int course_size;
        int student_size;

        public:

        SchoolManagementSystem();
        SchoolManagementSystem(const SchoolManagementSystem &obj);

        // our menu and menu options
        void menu();
        void student_menu();
        void course_menu();
        void list_all_students();
        void list_all_courses();
        void select_student();
        void select_course();


        ~SchoolManagementSystem();


    };

}





#endif