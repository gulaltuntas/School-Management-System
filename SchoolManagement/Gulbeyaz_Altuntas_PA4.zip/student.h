#ifndef STUDENT_H
#define STUDENT_H
#include <string>
#include <iostream>
#include "course.h"


using namespace std;

namespace PA4{
    
class Course;

class Student{

    private:
    string student_name;
    int student_id;
    int size;
    Course *courseReference;
    public:
    Student();
    Student(string name, int id);
    Student(const Student &obj);
    void setName(string name);
    void setID(int num);
    void setSize(int ssize);
    int getSize() const;
    int getID() const;
    string getName() const;
    Student &operator=(const Student &obj);

    void addCourse(Course c);
    bool deleteCourse(Course c);
    
    friend class SchoolManagementSystem; // added friend class to have access to priv members
    
    ~Student();

};

}

#endif