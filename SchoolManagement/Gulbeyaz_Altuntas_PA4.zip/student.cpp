#include "student.h"


namespace PA4{
Student::Student(){ // default
    student_name = "";
    student_id = 0;
    size = 0;
    courseReference = nullptr;
}

Student::Student(string name, int id){
    student_name = name;
    student_id = id;
    size = 0;
    courseReference = nullptr;
}
Student::Student(const Student &obj){  // copy
    student_name = obj.student_name;
    student_id = obj.student_id;
    size = obj.size;
    courseReference = new Course[size];
    for (int i = 0; i < size; i++){
        courseReference[i] = obj.courseReference[i];
    }
}

Student &Student::operator=(const Student &obj){ // assignment
    if (this == &obj){
        return *this;
    }
    student_name = obj.student_name;
    student_id = obj.student_id;
    size = obj.size;
    courseReference = new Course[size];
    for (int i = 0; i < size;i++){
        courseReference[i] = obj.courseReference[i];
    }

    return *this;
}

void Student::setName(string name){
    student_name = name;
}

void Student::setID(int number){
    student_id = number;
}
void Student::setSize(int ssize){
    size = ssize;
}
int Student::getSize() const{return size;}
int Student::getID() const{return student_id;}
string Student::getName() const{return student_name;}

void Student::addCourse(Course c){  // add course to a student
    Course *temp = new Course [size + 1]; 
    for (int i = 0; i < size; i++){
        temp[i] = courseReference[i];
    }
    temp[size] = c;

    if (size != 0){  
    delete [] courseReference;
    }
    courseReference = temp;
    size++;
}

bool Student::deleteCourse(Course c){ // delete course from a student
     int index = -1;
    for (int i = 0; i < size; i++){
        if (courseReference[i].getCode() == c.getCode()){
            index = i;
        }
    }
    if (index == -1){
        return false;
    }

    Course *temp = new Course [size - 1];
    for (int i = 0; i < index; i++){
        temp[i] = courseReference[i];
    }

    for (int i = index + 1; i < size; i++){
        temp[i - 1] = courseReference[i];
    }
    delete [] courseReference;
    courseReference = temp;
    size--;
    return true;
}


Student::~Student(){ // destructor

    if(courseReference != nullptr) {
        delete[] courseReference;
     } 
}


}