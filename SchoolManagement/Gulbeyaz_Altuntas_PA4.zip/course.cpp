#include "course.h"

namespace PA4{
Course::Course(){ // default
    course_name = "";
    course_code = "";
    size = 0;
    studentReference = nullptr;
}

Course::Course(string name, string code){
    course_name = name;
    course_code = code;
    size = 0;
    studentReference = nullptr;
}

Course::Course(const Course &obj){ // copy
    course_name = obj.course_name;
    course_code = obj.course_code;
    size = obj.size;
    studentReference = new Student[size];
    for (int i = 0; i < size; i++){
        studentReference[i] = obj.studentReference[i];
    }
}

Course &Course::operator=(const Course &obj){ // assignment
    
    if (this == &obj){
        return *this;
    }
    course_name = obj.course_name;
    course_code = obj.course_code;
    size = obj.size;

    studentReference = new Student[size];
    for (int i = 0; i < size;i++){
        studentReference[i] = obj.studentReference[i];
    }
    return *this;
}

void Course::setName(string name){
    course_name = name;
}

void Course::setCode(string number){
    course_code = number;
}

void Course::setSize(int s_size){
    size = s_size;
}

int Course::getSize() const{return size;}
string Course::getName() const{return course_name;}
string Course::getCode() const{return course_code;}


void Course::addStudent(Student s){ // adds student to a course
    Student *temp = new Student [size + 1]; 
    for (int i = 0; i < size; i++){
        temp[i] = studentReference[i];
    }
    temp[size] = s;
    if (size != 0){
     delete [] studentReference;
    }
    studentReference = temp;
    size++;
}

bool Course::deleteStudent(Student s){ // delete student from a class
     int index = -1;
    for (int i = 0; i < size; i++){
        if (studentReference[i].getID() == s.getID()){
            index = i;
        }
    }
    if (index == -1){
        return false;
    }

    Student *temp = new Student [size - 1];
    for (int i = 0; i < index; i++){
        temp[i] = studentReference[i];
    }

    for (int i = index + 1; i < size; i++){
        temp[i - 1] = studentReference[i];
    }
    delete [] studentReference;
    studentReference = temp;
    size--;
    return true;
}


Course::~Course(){ // destructor

    if(studentReference != nullptr) {
        delete[] studentReference;
     } 
}


}