#ifndef COURSE_H
#define COURSE_H
#include <string>
#include <iostream>
#include "student.h"

using namespace std;

namespace PA4{
class Student;

class Course{

    private:
    string course_name;
    string course_code;
    int size;
    Student *studentReference;

    public:
    Course();
    Course(string name, string code);
    Course(const Course &obj);
    void setName(string name);
    void setCode(string number);
    void setSize(int s_size);
    int getSize() const;
    string getCode() const;
    string getName() const;
    Course &operator=(const Course &obj);

    void addStudent(Student s);
    bool deleteStudent(Student s);

    friend class SchoolManagementSystem; // added friend class to access to priv members

    ~Course();

};


}

#endif