#include <iostream>
#include <string>
#include "SchoolManagementSystem.h"

using namespace PA4;


int main(){
    SchoolManagementSystem manager; // creating our object
    manager.menu(); // calling the menu
    return 0;
}